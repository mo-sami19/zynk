"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "_rsc_locales_ar_common_json";
exports.ids = ["_rsc_locales_ar_common_json"];
exports.modules = {

/***/ "(rsc)/./locales/ar/common.json":
/*!********************************!*\
  !*** ./locales/ar/common.json ***!
  \********************************/
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"nav":{"home":"الرئيسية","services":"الخدمات","projects":"المشاريع","about":"من نحن","blog":"المدونة","contact":"اتصل بنا","getStarted":"ابدأ الآن"},"home":{"badge":"التميز في التسويق الرقمي","heroTitle":"عزز علامتك التجارية مع","heroSubtitle":"التميز الإبداعي","heroDescription":"حوّل حضورك الرقمي باستراتيجيات تسويقية متطورة تحقق نتائج حقيقية. نجمع بين الإبداع والرؤى المستندة إلى البيانات لرفع مستوى علامتك التجارية.","getStarted":"ابدأ الآن","viewWork":"شاهد أعمالنا","clients":"عميل سعيد","awards":"جائزة","projects":"مشروع مكتمل","satisfaction":"معدل الرضا","servicesTitle":"خدماتنا","servicesDescription":"حلول تسويق رقمي شاملة مصممة خصيصاً لاحتياجات عملك","service1Title":"التسويق عبر وسائل التواصل","service1Desc":"بناء حضور قوي على وسائل التواصل الاجتماعي وإشراك جمهورك باستراتيجيات محتوى مقنعة.","service2Title":"تسويق المحتوى","service2Desc":"إنشاء محتوى قيم يجذب جمهورك المستهدف ويشركه ويحوله إلى عملاء.","service3Title":"الإعلانات المدفوعة","service3Desc":"جذب حركة مرور مستهدفة وتعظيم العائد على الاستثمار من خلال حملات إعلانية استراتيجية.","learnMore":"اعرف المزيد","ctaTitle":"هل أنت مستعد لتحويل حضورك الرقمي؟","ctaDescription":"دعنا نصنع شيئاً مذهلاً معاً. تواصل مع فريقنا اليوم.","ctaButton":"ابدأ مشروعك","startProject":"ابدأ مشروعك","exploreServices":"استكشف الخدمات","awardWinning":"وكالة حائزة على جوائز","trustedByHundreds":"موثوق به من قبل أكثر من 500 عميل","fastDelivery":"تسليم سريع وموثوق"},"footer":{"description":"شريكك الموثوق للتميز في التسويق الرقمي. نساعد العلامات التجارية على النمو من خلال استراتيجيات مبتكرة وحلول إبداعية.","quickLinks":"روابط سريعة","home":"الرئيسية","services":"الخدمات","projects":"المشاريع","about":"من نحن","socialMedia":"التسويق عبر وسائل التواصل","contentMarketing":"تسويق المحتوى","ppc":"الإعلانات المدفوعة","branding":"الهوية والعلامة التجارية","contact":"اتصل بنا","rights":"جميع الحقوق محفوظة.","privacy":"سياسة الخصوصية","terms":"شروط الخدمة"}}');

/***/ })

};
;