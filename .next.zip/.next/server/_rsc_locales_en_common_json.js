"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "_rsc_locales_en_common_json";
exports.ids = ["_rsc_locales_en_common_json"];
exports.modules = {

/***/ "(rsc)/./locales/en/common.json":
/*!********************************!*\
  !*** ./locales/en/common.json ***!
  \********************************/
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"nav":{"home":"Home","services":"Services","projects":"Projects","about":"About","blog":"Blog","contact":"Contact","getStarted":"Get Started"},"home":{"badge":"Digital Marketing Excellence","heroTitle":"Elevate Your Brand with","heroSubtitle":"Creative Innovation","heroDescription":"Transform your digital presence with cutting-edge marketing strategies that drive real results. We combine creativity with data-driven insights to elevate your brand.","getStarted":"Get Started","viewWork":"View Our Work","clients":"Happy Clients","awards":"Awards Won","projects":"Projects Completed","satisfaction":"Satisfaction Rate","servicesTitle":"Our Services","servicesDescription":"Comprehensive digital marketing solutions tailored to your business needs","service1Title":"Social Media Marketing","service1Desc":"Build a powerful social presence and engage your audience with compelling content strategies.","service2Title":"Content Marketing","service2Desc":"Create valuable content that attracts, engages, and converts your target audience.","service3Title":"PPC Advertising","service3Desc":"Drive targeted traffic and maximize ROI with strategic paid advertising campaigns.","learnMore":"Learn More","ctaTitle":"Ready to Transform Your Digital Presence?","ctaDescription":"Let\'s create something amazing together. Get in touch with our team today.","ctaButton":"Start Your Project","startProject":"Start Your Project","exploreServices":"Explore Services","awardWinning":"Award Winning Agency","trustedByHundreds":"Trusted by 500+ Clients","fastDelivery":"Fast & Reliable Delivery"},"footer":{"description":"Your trusted partner for digital marketing excellence. We help brands grow through innovative strategies and creative solutions.","quickLinks":"Quick Links","home":"Home","services":"Services","projects":"Projects","about":"About Us","socialMedia":"Social Media Marketing","contentMarketing":"Content Marketing","ppc":"PPC Advertising","branding":"Branding & Identity","contact":"Contact Us","rights":"All rights reserved.","privacy":"Privacy Policy","terms":"Terms of Service"}}');

/***/ })

};
;